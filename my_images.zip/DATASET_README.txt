OPIM 5509 Assignment 4 — student-assembled collection of rose and sunflower photographs
Sources: independently selected Wikimedia Commons photo-category files.
Photos were taken by the respective credited photographers; they are NOT original student photographs.
A resized JPEG is stored for each file. Original pages, authors and license links are in CREDITS.csv.
Image rights remain with original creators; observe individual file licenses and attribution.
